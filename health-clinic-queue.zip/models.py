from datetime import datetime

class Patient:
    def __init__(self, name, age):
        self.name = name
        self.age = age
        self.time_registered = datetime.now()

    def display_info(self):
        return f"{self.name} ({self.age}) - {self.time_registered.strftime('%H:%M:%S')}"
