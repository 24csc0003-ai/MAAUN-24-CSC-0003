# Health Clinic Queue Manager

## What This App Does
A simple Flask web app to manage patient queues.

## Features
- Add patients
- View queue
- Serve patients
- Count served patients

## How to Run

1. Install Python
2. Install Flask:
   pip install Flask
3. Run:
   python app.py
4. Open browser:
   http://127.0.0.1:5000/
